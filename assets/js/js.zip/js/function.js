$(document).ready(function () {    
  $('form').on("submit",function(e){ 
    //alert("Sdasdad");   
    formname = $(this).attr("name"); 
    /*Skip Ajax*/ 
    var skip=['frmSearchsanatha','frmSearchjobview','payuForm','loginForm','frmflaggedusers'];
    var skipthis=0;
    $.each( skip, function( index, value ){
        if(formname==value){         
          skipthis=1;
          //break;     
        }
    });
    if(skipthis==1){
      return;
    }    
    /*Skip Ajax End*/
    e.preventDefault();   
    fd = new FormData(this); 
    page = $(this).attr('action');
    method='';
    if(formname!= 'login_form'){
      method=$('#doValidation').val();
    } 
    if(callClientValidation(method)){
        callAjax(fd,page);  
    }  
  });
});
function addLoader(){ 
  $('#dvLoading').show();
}
function removeLoader(){ 
 $('#dvLoading').hide();   
}
function callAjax(fd,pg)
{  
  isSubmitting = true;
  console.log(fd.seralize);
  $.ajax({
    url: pg,
    type: "POST",
    dataType: "json",
    data:  fd,
    contentType:false,
    processData:false, 
    beforeSend: function() 
    {
      $("button[type='submit']").attr('disabled','disabled');    
      $("input[type='submit']").attr('disabled','disabled');
      addLoader(); 
    },
    success: function(json) 
    { 
      console.log("success"); 
      console.log(json);  
      if(json.res_code==1){
        callfunction(json);
      }    
    },
   /* error: function(e) 
    {
      console.log(e);
      alert('ajax call failed'+e);
    },*/
    complete: function(json) 
    {
      console.log("complete");
      isSubmitting = false;
      removeLoader();
      $("button[type='submit']").removeAttr('disabled');
      $("input[type='submit']").removeAttr('disabled');
    }
  });
}
function customAjax(pg,fd){  
  fd=JSON.parse(fd);
  $.ajax({
    url: pg,
    type: "POST",
    dataType: "json",
    data: fd,
    /*contentType:false,
    processData:false, */
    success: function(json) 
    { 
      console.log("success"); 
      //console.log(json);  
      if(json.res_code==1){
        callfunction(json);
      }    
    }
  });
}
function callfunction(data){ 
  console.log(data);
  switch(data.method){    
    case'loginErrorMsg':
      loginErrorMsg(data);
    break;  
    case'RegSuccMsg':
      RegSuccMsg(data);
    break;
    case'RegErrorMsg':
      RegErrorMsg(data);
    break;
    case'recRegSuccMsg':
      recRegSuccMsg(data);
    break;    
    case'Newsletter':
      Newsletter(data);
    break;  
    case'SuccMsgNoRefresh':
      SuccMsgNoRefresh(data);
    break;
    case'reload':
      reload();
    break;  
    case 'userRating':
        userRating(data);
      break;
    case 'feedbackalert':
        feedbackalert(data);
      break;
      case 'RegInfoMsg':
        RegInfoMsg(data);
      break;
    default:

    break;
  }
}
function callClientValidation(method){
   switch(method){
    case'validate_register':
      return validateRegForm();
    break;
    case'validate_business':
      return validateBusiForm();
    break;
    default:
      return true;
    break;
  }
}

function feedbackalert(data){
  swal(data.heading,data.feedback);
}

function RegInfoMsg(data){
  swal("Information",data.message,"info");
}




